# أحمد الصبوي — Android APK Project

مشروع Android Studio يحوّل نسخة لعبة الجري الموجودة في `app/src/main/assets/index.html`
إلى تطبيق Android باستخدام WebView.

## بناء APK
1. افتح المجلد `AhmedAlSabawyAndroid` في Android Studio.
2. انتظر مزامنة Gradle.
3. من القائمة: Build > Build APK(s).
4. ملف APK التجريبي سيكون عادةً داخل:
   `app/build/outputs/apk/debug/app-debug.apk`

## ملاحظات
- اسم التطبيق: أحمد الصبوي
- package: com.ahmedalsabawy.game
- الاتجاه: Portrait
- اللعبة تعمل محليًا بدون إنترنت لأنها داخل assets.
